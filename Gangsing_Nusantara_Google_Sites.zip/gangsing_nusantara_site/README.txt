GANGSING NUSANTARA — Website game untuk Google Sites

ISI FOLDER
- index.html : halaman utama + interaksi tombol
- assets/cover-gangsing-nusantara.png : gambar cover Slide 1

CARA MENJALANKAN LOKAL
1. Ekstrak ZIP.
2. Pastikan index.html dan folder assets berada dalam folder yang sama.
3. Buka index.html menggunakan browser.

CARA MEMASANG DI GOOGLE SITES
Google Sites tidak meng-host file HTML/CSS/JS sebagai situs penuh secara langsung.
Cara yang disarankan:
1. Upload folder project ini ke sebuah repository GitHub.
2. Aktifkan GitHub Pages pada repository (Settings > Pages > Deploy from a branch).
3. Pilih branch main dan folder /(root), lalu Save.
4. Setelah GitHub Pages memberikan URL website, buka Google Sites.
5. Pilih Insert > Embed > By URL.
6. Tempel URL GitHub Pages, lalu Insert.
7. Atur ukuran embed agar lebar dan rasio tampilannya sesuai.

CATATAN
- Jangan memisahkan index.html dari folder assets.
- Tombol cover sudah memiliki area klik transparan yang diletakkan di atas tombol pada gambar.
- Menu MAP, ensiklopedia, leaderboard, dan pengaturan saat ini adalah kerangka interaktif awal.
- Konten lengkap 7 MAP dan 20 soal belum dimasukkan ke website ini; dapat dikembangkan pada tahap berikutnya.
- Untuk hasil terbaik, tampilkan Google Sites dalam mode publik atau pastikan izin akses GitHub Pages dapat dibuka oleh pengunjung.
